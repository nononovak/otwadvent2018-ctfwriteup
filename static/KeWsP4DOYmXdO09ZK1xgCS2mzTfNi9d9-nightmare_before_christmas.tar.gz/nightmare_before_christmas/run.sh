#!/bin/bash
qemu-arm -L ./ ./nightmare
